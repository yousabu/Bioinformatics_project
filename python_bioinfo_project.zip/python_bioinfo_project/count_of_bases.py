

def find_count(seq):
    A = seq.count("A")
    T = seq.count("T")
    C = seq.count("C")
    G = seq.count("G")

    print("Count of A base: ", A)
    print("Count of A base: ", T)
    print("Count of A base: ", C)
    print("Count of A base: ", G)


