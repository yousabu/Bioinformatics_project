def reverse(seq):
    recom = list(seq)
    x = ''.join(recom)
    return x[::-1]